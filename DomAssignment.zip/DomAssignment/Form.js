document.getElementById("submit").addEventListener('click', function(){
    var userName = document.getElementById("userName").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    if (password != "12345678"){
    	alert("Information is not correct");
    } else{
    	document.getElementById("welcome").innerHTML = "Thank you, your information is correct";  
    }
  
});
