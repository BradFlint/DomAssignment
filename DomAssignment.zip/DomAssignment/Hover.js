document.getElementsByTagName('h1')[0].addEventListener('mouseover', function(){
    document.getElementsByTagName('h1')[0].innerText = "Hey, I told you not to hover over me!";
});